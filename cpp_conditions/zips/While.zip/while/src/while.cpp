//============================================================================
// Name        : while.cpp
// Author      : John Purcell
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
using namespace std;

int main() {

	int i = 0;

	while(i < 5) {
		cout << "Hello " << i << endl;

		i++; // Increments i by 1
	}

	cout << "Programming quitting." << endl;

	return 0;
}
